import React from 'react';
import TocInfo from './TocInfo'

    const TOC = ({ contents, CHANGE_MODE, SELECT }) => {
    
    }

  export default TOC;